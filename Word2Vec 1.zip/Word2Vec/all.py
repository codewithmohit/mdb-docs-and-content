
headers = {
  'Accept': 'gateway-token=CwzdX78FdqKMLiMeNpnQPIdKCzND;',
  'Accept-Language': 'en-US,en;q=0.9',
  'Connection': 'keep-alive',
  'Cookie': 'AEM_POST_FLAG=true; _gcl_au=1.1.865754590.1712913745; sd_client_id=b6279dea-f6db-430c-aa98-6cd39f080e90; _fbp=fb.1.1712913750222.510750478; wfx_unq=KzbAcs6z6svosAKX; _vis_opt_s=1%7C; _vwo_uuid=DC0678C545C3E879EE1C5878BD3BCC95F; _vwo_ds=3%3At_0%2Ca_0%3A0%241712916748%3A88.31324273%3A%3A%3A1018_0%2C993_0%3A0; _gid=GA1.2.1016985220.1719852432; at_check=true; mboxEdgeCluster=37; csrfToken=Tty70THxmzCTso8U0psG/XgievR7lXN+1mhy0H/meMw+; AWSALB=ol4IyaOW5wnq89awlV4r9ZPrqNgTwDc3DlAU3dVHoWUecMBjG+LCv1QQlyUEzeidnus4v+A5tW6C85emTtWcMpvyzm3TgAYYP2CTvadI66GTQf/pcJiGnvI+fCqa; AWSALBCORS=ol4IyaOW5wnq89awlV4r9ZPrqNgTwDc3DlAU3dVHoWUecMBjG+LCv1QQlyUEzeidnus4v+A5tW6C85emTtWcMpvyzm3TgAYYP2CTvadI66GTQf/pcJiGnvI+fCqa; ADRUM=s=1719917332635&r=https%3A%2F%2Fqab.rci.com%2Fpre-rci%2Fus%2Fen%2Fresort-directory%2Fresortdetails%3F1332022236; _ga_YGN5V1XHMN=GS1.1.1719915658.7.1.1719917334.59.0.0; _ga=GA1.2.524755095.1712913746; _dc_gtm_UA-105225660-2=1; mbox=PC^#ba31149b9427485f8c914dbf25816b4f.37_0^#1783162137|session^#d2c1005b6e364f8f90def66d16a900e2^#1719919197; access_token=CwzdX78FdqKMLiMeNpnQPIdKCzND; refresh_token=2k1OAQX3d7kquNvtkKkCjqQXS9AaV8Ma; ADRUM_BT1=R:20|i:1346957; ADRUM_BTa=R:20|g:caa7a2dd-d531-4483-83c8-86dfa63851bd|n:wyndhamdestinations-test_57db9f7c-a837-4007-a884-b2b57d6dacab; ADRUM_BTs=R:20|s:f; AWSALB=D1npL6oM491tYYtf+ww2cG4EpMSIciYyy+1PaKjpdqNBCoOYp58fSEJxbBx/Xes873v+gwwQSIrmrBnI1M5319C/j+HmUiMHTJa/tyJ3vfrYRKHmKutM829lPL1M; AWSALBCORS=D1npL6oM491tYYtf+ww2cG4EpMSIciYyy+1PaKjpdqNBCoOYp58fSEJxbBx/Xes873v+gwwQSIrmrBnI1M5319C/j+HmUiMHTJa/tyJ3vfrYRKHmKutM829lPL1M; SameSite=None',
  'Origin': 'https://qab.rci.com',
  'Referer': 'https://qab.rci.com/',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-site',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"'
}
headers = {
  'Accept': 'gateway-token=CwzdX78FdqKMLiMeNpnQPIdKCzND;',
  'Accept-Language': 'en-US,en;q=0.9',
  'Connection': 'keep-alive',
  'Content-Type': 'text/plain',
  'Cookie': 'AEM_POST_FLAG=true; _gcl_au=1.1.865754590.1712913745; sd_client_id=b6279dea-f6db-430c-aa98-6cd39f080e90; _fbp=fb.1.1712913750222.510750478; wfx_unq=KzbAcs6z6svosAKX; _vis_opt_s=1%7C; _vwo_uuid=DC0678C545C3E879EE1C5878BD3BCC95F; _vwo_ds=3%3At_0%2Ca_0%3A0%241712916748%3A88.31324273%3A%3A%3A1018_0%2C993_0%3A0; _gid=GA1.2.1016985220.1719852432; at_check=true; mboxEdgeCluster=37; csrfToken=Tty70THxmzCTso8U0psG/XgievR7lXN+1mhy0H/meMw+; AWSALB=ol4IyaOW5wnq89awlV4r9ZPrqNgTwDc3DlAU3dVHoWUecMBjG+LCv1QQlyUEzeidnus4v+A5tW6C85emTtWcMpvyzm3TgAYYP2CTvadI66GTQf/pcJiGnvI+fCqa; AWSALBCORS=ol4IyaOW5wnq89awlV4r9ZPrqNgTwDc3DlAU3dVHoWUecMBjG+LCv1QQlyUEzeidnus4v+A5tW6C85emTtWcMpvyzm3TgAYYP2CTvadI66GTQf/pcJiGnvI+fCqa; ADRUM=s=1719917332635&r=https%3A%2F%2Fqab.rci.com%2Fpre-rci%2Fus%2Fen%2Fresort-directory%2Fresortdetails%3F1332022236; _ga_YGN5V1XHMN=GS1.1.1719915658.7.1.1719917334.59.0.0; _ga=GA1.2.524755095.1712913746; _dc_gtm_UA-105225660-2=1; mbox=PC^#ba31149b9427485f8c914dbf25816b4f.37_0^#1783162137|session^#d2c1005b6e364f8f90def66d16a900e2^#1719919197; access_token=CwzdX78FdqKMLiMeNpnQPIdKCzND; refresh_token=2k1OAQX3d7kquNvtkKkCjqQXS9AaV8Ma; ADRUM_BT1=R:20|i:535170; ADRUM_BTa=R:20|g:b55ab07c-b959-4c6b-977b-bff27e140bd8|n:wyndhamdestinations-test_57db9f7c-a837-4007-a884-b2b57d6dacab; ADRUM_BTs=R:20|s:f; AWSALB=1qWaw8gYWxlUAWK9+E9IYeQYouirSdPBnNvqZVRvrG+Di90Z68fsJGADkc4cFQLxZrj3Ii0gUQb2Cp0EaVPKQHgms7mbEwesBcYFerSwGwny/5wmuk8NSbwiu85Z; AWSALBCORS=1qWaw8gYWxlUAWK9+E9IYeQYouirSdPBnNvqZVRvrG+Di90Z68fsJGADkc4cFQLxZrj3Ii0gUQb2Cp0EaVPKQHgms7mbEwesBcYFerSwGwny/5wmuk8NSbwiu85Z; SameSite=None',
  'Origin': 'https://qab.rci.com',
  'Referer': 'https://qab.rci.com/',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-site',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"'
}
headers = {
  'Accept': 'gateway-token=CwzdX78FdqKMLiMeNpnQPIdKCzND;',
  'Accept-Language': 'en-US,en;q=0.9',
  'Connection': 'keep-alive',
  'Cookie': 'AEM_POST_FLAG=true; _gcl_au=1.1.865754590.1712913745; sd_client_id=b6279dea-f6db-430c-aa98-6cd39f080e90; _fbp=fb.1.1712913750222.510750478; wfx_unq=KzbAcs6z6svosAKX; _vis_opt_s=1%7C; _vwo_uuid=DC0678C545C3E879EE1C5878BD3BCC95F; _vwo_ds=3%3At_0%2Ca_0%3A0%241712916748%3A88.31324273%3A%3A%3A1018_0%2C993_0%3A0; _gid=GA1.2.1016985220.1719852432; at_check=true; mboxEdgeCluster=37; csrfToken=Tty70THxmzCTso8U0psG/XgievR7lXN+1mhy0H/meMw+; ADRUM=s=1719917332635&r=https%3A%2F%2Fqab.rci.com%2Fpre-rci%2Fus%2Fen%2Fresort-directory%2Fresortdetails%3F1332022236; _ga_YGN5V1XHMN=GS1.1.1719915658.7.1.1719917334.59.0.0; _ga=GA1.2.524755095.1712913746; _dc_gtm_UA-105225660-2=1; mbox=PC^#ba31149b9427485f8c914dbf25816b4f.37_0^#1783162137|session^#d2c1005b6e364f8f90def66d16a900e2^#1719919197; access_token=CwzdX78FdqKMLiMeNpnQPIdKCzND; refresh_token=2k1OAQX3d7kquNvtkKkCjqQXS9AaV8Ma; AWSALB=9+tfEVMygKw7u/+judKyvQ+vehweUxWBNNFVLaU6jCrOG21kyMTvHt3ekDkcHcjQy8UlCMyE8uk7kxiapypZSBT+hhpd6XTHgJ8tIW88EjAROoCGpAJwZhYKV7km; AWSALBCORS=9+tfEVMygKw7u/+judKyvQ+vehweUxWBNNFVLaU6jCrOG21kyMTvHt3ekDkcHcjQy8UlCMyE8uk7kxiapypZSBT+hhpd6XTHgJ8tIW88EjAROoCGpAJwZhYKV7km; ADRUM_BTa=R:20|g:370d0fd3-9df5-4e29-a8e7-f57ecb0dbf84|n:wyndhamdestinations-test_57db9f7c-a837-4007-a884-b2b57d6dacab; SameSite=None; ADRUM_BT1=R:20|i:529281|e:1966; ADRUM_BT1=R:20|i:535248|e:279; ADRUM_BTa=R:20|g:ffb36410-bb83-45df-9e32-caf6979d7254|n:wyndhamdestinations-test_57db9f7c-a837-4007-a884-b2b57d6dacab; ADRUM_BTs=R:20|s:f; AWSALB=GglHnQ8yofJvyHbbiLFfOLsM0oFlJb6Hk3BXtXWlsAgPif+zCV1a1aTrCDAQ7/ETw1KzaLiiYLzeEn9z7I9hX63entvRo+S9WXA/jnbOJCaiV8gjG1C/NJGthF8C; AWSALBCORS=GglHnQ8yofJvyHbbiLFfOLsM0oFlJb6Hk3BXtXWlsAgPif+zCV1a1aTrCDAQ7/ETw1KzaLiiYLzeEn9z7I9hX63entvRo+S9WXA/jnbOJCaiV8gjG1C/NJGthF8C; SameSite=None',
  'Origin': 'https://qab.rci.com',
  'Referer': 'https://qab.rci.com/',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-site',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
  'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"'
}





